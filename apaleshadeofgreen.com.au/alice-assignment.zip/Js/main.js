$(function() {
	var $box = $('#box');

	$('#readmore').on('click',expandreadmore);
	$('#btnShow').on('click',buttonShow);
	$('#btnSlideUp').on('click',buttonSlideUp);
	$('#btnSlideDown').on('click',buttonSlideDown);
	$('#btnHTML').on('click',htmlBoom);
	$('#btnAnimate').on('click',animateButton);
	

	function expandreadmore() {
		
		$box.slideDown();

	}

	function buttonShow() {
	
		$box.show();

	}


	function buttonSlideUp() {
	
		$box.slideUp();

	}



	function buttonSlideDown() {
		
		$box.slideDown();

	}


	function htmlBoom() {
	
	$box.append('<h1>BOOM</h1>');

	}


	function animateButton() {
	
	$box.animate({
    opacity: 0.1,
    left: "+=50",
    height: "toggle"
  }, 1000, function() {
    // Animation complete.
  });

	}


	
});


// Single Line Comments

/* 

Multi line comments 
can be big blocks like this

*/